import React from 'react'
import ReactDOM from 'react-dom/client'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import { ChakraProvider } from '@chakra-ui/react'
import LoginComponent from './components/LoginComponent.jsx'
import RegisterComponent from './components/RegisterComponent.jsx'
import { AuthProvider } from './context/AuthContext.jsx'
import Dashboard from './components/Dashboard.jsx'
import Projects from './components/Projects.jsx'
import ProjectBoards from './components/ProjectBoards.jsx'

const router = createBrowserRouter([
  {
    path: '/',
    element: <LoginComponent />
  },
  {
    path: '/register',
    element: <RegisterComponent />
  },
  {
    path: '/dashboard',
    element: <Dashboard />,
    children: [
      {
        path: '/dashboard/',
        element: <Projects />
      },
      {
        path: '/dashboard/:projectId',
        element: <ProjectBoards />
      }
    ]
  }
])

ReactDOM.createRoot(document.getElementById('root')).render(
  <AuthProvider>
    <ChakraProvider>
      <RouterProvider router={router}></RouterProvider>
    </ChakraProvider>
  </AuthProvider>
)
