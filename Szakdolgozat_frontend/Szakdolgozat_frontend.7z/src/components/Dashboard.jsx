import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import {
    Box, Text, Avatar,
    IconButton, Button,
    Spacer,
    Stack,
    Flex
} from '@chakra-ui/react';

import { AiFillProject, AiOutlineProject } from "react-icons/ai";
import { FaArrowLeft, FaArrowRight, FaTasks } from "react-icons/fa";
import { useEffect } from 'react';
import { BiLogOut } from 'react-icons/bi';
import { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { motion } from 'framer-motion';

export default function Dashboard() {

    const { user, logout } = useAuth()
    const navigate = useNavigate()

    const [opened, setOpened] = useState(true)

    /* const refreshTokenHandler = async () => {
        const response = await renewAccessTokenWithRefreshToken(user.accessToken, user.refreshToken)
        localStorage.setItem("user", JSON.stringify({
            ...user, accessToken: response.accessTokenNew, refreshToken: response.refreshTokenNew,
        }))
        setUser({
            ...user, accessToken: response.accessTokenNew, refreshToken: response.refreshTokenNew,
        })
        window.location.reload()
    } */
    useEffect(() => {
        if (!user) {
            navigate('/')
        }

    }, [user])

    if (user == null) {
        return ""
    } else
        return (
            <Flex gap={"10px"}>
                <Box
                    w={opened ? "250px" : "60px"}
                    h="100vh"
                    bg="gray.200"
                    left="0"
                    top="0"
                    display="flex"
                    flexDirection="column"
                    gap="10px"
                    as={motion.div}
                    transition={"0.3s linear"}
                >
                    <Stack justify={"center"} align="center" p={4} bgColor="gray.300" direction={"row"}>
                        {opened ? <><AiFillProject color='blue' size={30} />
                            <Text fontSize="lg" fontWeight="bold">
                                PM
                            </Text>                        <Spacer />
                        </> : ""}
                        <IconButton onClick={() => setOpened(!opened)} icon={opened ? <FaArrowLeft /> : <FaArrowRight />} />
                    </Stack>

                    <Stack gap={3} align="center" direction={"row"} p={2}>
                        <Avatar name={`${user.lastName} ${user.firstName}`} borderRadius={10} />
                        <Stack display={opened ? "" : "none"} gap={"2px"}>
                            <Text fontWeight={"bold"}>{`${user.lastName} ${user.firstName}`}</Text>
                            <Text fontSize={"small"}>{`${user.email}`}</Text>
                        </Stack>
                    </Stack>

                    <Button onClick={() => navigate('/dashboard')} leftIcon={<AiOutlineProject />} variant={"ghost"}>{opened ? "Projektek" : ""} </Button>
                    <Button leftIcon={<FaTasks />} variant={"ghost"}>{opened ? "Saját feladataim" : ""}</Button>
                    <Spacer />
                    <Button onClick={() => logout()} variant={"ghost"} leftIcon={<BiLogOut />} mb={2}>{opened ? "Kijelentkezés" : ""}</Button>
                </Box>
                <Outlet />
            </Flex>
        )
}
