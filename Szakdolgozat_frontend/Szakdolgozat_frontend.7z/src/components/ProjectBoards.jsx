import React from 'react'
import { useParams } from 'react-router-dom'
import { Flex } from "@chakra-ui/react"
import { useState } from 'react'
import { useEffect } from 'react'
import { useAuth } from '../context/AuthContext'
import { getProjectById } from '../api/project'
import {
    Breadcrumb,
    BreadcrumbItem,
    BreadcrumbLink,
    HStack,
    Box,
    Avatar,
    Text,
    Heading,
    Tooltip, Button, Input, FormLabel, FormErrorMessage,
    Modal, ModalOverlay, Stack, ModalContent, Select, Textarea, ModalHeader, ModalCloseButton, ModalBody, ModalFooter, FormControl, useDisclosure, useToast, Spacer, IconButton
} from '@chakra-ui/react'
import { Link } from 'react-router-dom'
import { FaPlus } from 'react-icons/fa'
import { addProjectBoard, getProjectBoards } from '../api/projectBoard'
import { useForm } from 'react-hook-form'
import { BsThreeDots } from "react-icons/bs"

import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd"

export default function ProjectBoards() {

    const { user } = useAuth()
    const { projectId } = useParams()
    const [project, setProject] = useState()
    const [boards, setBoards] = useState()

    const { isOpen, onOpen, onClose } = useDisclosure()
    const { isOpen: isOpenAddIssue, onOpen: onOpenAddIssue, onClose: onCloseAddIssue } = useDisclosure()

    const [loading, setLoading] = useState(true)
    const { register, handleSubmit, reset, formState: { errors } } = useForm();

    const toast = useToast()

    useEffect(() => {
        const fetchProject = async () => {
            const result = await getProjectById(user.accessToken, projectId)
            setProject(result.data)
        }
        fetchProject()
    }, [])

    useEffect(() => {
        const fetchProjectBoards = async () => {
            const result = await getProjectBoards(projectId, user.accessToken)
            setBoards(result.data)
        }
        fetchProjectBoards()
    }, [])

    const handleAddBoard = async (data) => {
        try {
            await addProjectBoard(project.id, user.accessToken, { title: data.title, position: boards.length + 1 })
            toast({
                title: 'Board sikeresen létrehozva a projekthez.',
                description: "",
                status: 'success',
                duration: 4000,
                isClosable: true,
            })
            handleCloseAddBoard()
        } catch (e) {
            toast({
                title: 'Hiba történt a board hozzáadása közben...',
                description: "",
                status: 'error',
                duration: 4000,
                isClosable: true,
            })
            handleCloseAddBoard()
        }
    }

    const handleCloseAddBoard = () => {
        reset()
        onClose()
    }

    if (project == null)
        return <Flex w={"90%"} flexDir={"column"} justify={"center"} align="center">
            <Heading>404</Heading>
            <Text>A megadott projekt nem található.</Text>
        </Flex>
    else
        return (
            <>
                <Modal isOpen={isOpen} onClose={handleCloseAddBoard}>
                    <ModalOverlay />
                    <ModalContent>
                        <ModalHeader>Board hozzáadása a projekthez</ModalHeader>
                        <ModalCloseButton />
                        <form onSubmit={handleSubmit(handleAddBoard)}>
                            <ModalBody>
                                <FormControl isInvalid={errors.title}>
                                    <FormLabel>Tábla neve</FormLabel>
                                    <Input {...register("title", { required: true })} type="text" />
                                    {errors.title ? <FormErrorMessage>Kérem adja meg a tábla címét.</FormErrorMessage> : ""}
                                </FormControl>
                            </ModalBody>
                            <ModalFooter>
                                <Button type="submit" colorScheme='blue' mr={3} variant='solid'>Hozzárendel</Button>
                                <Button onClick={handleCloseAddBoard}>
                                    Visszavonás
                                </Button>
                            </ModalFooter>
                        </form>
                    </ModalContent>
                </Modal>

                <Modal size="xl" isOpen={isOpenAddIssue} onClose={onCloseAddIssue}>
                    <ModalOverlay />
                    <ModalContent>
                        <ModalHeader>Ügy létrehozása</ModalHeader>
                        <form>
                            <ModalBody>
                                <Stack spacing={5}>
                                    <FormControl>
                                        <FormLabel>Cím</FormLabel>
                                        <Input />
                                    </FormControl>
                                    <FormControl>
                                        <FormLabel>Leírás</FormLabel>
                                        <Textarea />
                                    </FormControl>
                                    <FormControl>
                                        <FormLabel>Bejelentő</FormLabel>
                                        <Select>
                                            {project && project.participants.map((i, k) => {
                                                return <option key={k}>{`${i.lastName} ${i.firstName}`}</option>
                                            })}
                                        </Select>
                                    </FormControl>
                                    <FormControl>
                                        <FormLabel>Hozzárendelt személyek</FormLabel>
                                        <Select>
                                            {project && project.participants.map((i, k) => {
                                                return <option key={k}>{`${i.lastName} ${i.firstName}`}</option>
                                            })}
                                        </Select>
                                    </FormControl>
                                    <FormControl>
                                        <FormLabel>Prioritás</FormLabel>
                                        <Select>
                                            <option>Legmagasabb</option>
                                            <option>Magas</option>
                                            <option>Közepes</option>
                                            <option>Alacsony</option>
                                            <option>Legalacsonyabb</option>
                                        </Select>
                                    </FormControl>
                                    <FormControl>
                                        <FormLabel>Határidő</FormLabel>
                                        <Input type="date" />
                                    </FormControl>
                                </Stack>
                            </ModalBody>
                        </form>
                        <ModalFooter>
                            <Button mr={3} colorScheme='blue'>Létrehozás</Button>
                            <Button onClick={onCloseAddIssue}>Visszavonás</Button>
                        </ModalFooter>

                    </ModalContent>
                </Modal>

                <Flex justify={"stretch"} gap={"20px"} flexDirection={"column"} mt={5}>
                    <Breadcrumb>
                        <BreadcrumbItem>
                            <BreadcrumbLink as={Link} to='/dashboard'>Összes projekt</BreadcrumbLink>
                        </BreadcrumbItem>
                        <BreadcrumbItem isCurrentPage>
                            <BreadcrumbLink href='#'>{project.title}</BreadcrumbLink>
                        </BreadcrumbItem>
                    </Breadcrumb>

                    <DragDropContext>
                        <HStack userSelect={"none"} gap={5} >
                            {boards && boards.map((i, k) => {
                                return <Droppable droppableId={`${i.id}`} direction='horizontal'>
                                    {provided => (
                                        <Stack
                                            {...provided.droppableProps}
                                            ref={provided.innerRef}
                                            key={k}
                                            height="90vh"
                                            width="200px"
                                            bg="gray.200"
                                            p={2}
                                            gap={5}
                                        >
                                            <HStack>
                                                <Text textTransform={"uppercase"}>{i.title} - {i.issues.length}</Text>
                                                <Spacer />
                                                <IconButton variant={"ghost"} icon={<BsThreeDots size={25} />} />
                                            </HStack>
                                            <Flex onClick={onOpenAddIssue} _hover={{ cursor: "pointer", bg: "gray.100" }} bg={"white"} align="center" borderRadius={5} p={1} justify={"center"}>
                                                <FaPlus />
                                                <Text>Ügy hozzáadása</Text>
                                            </Flex>
                                            {
                                                i.issues.map((issue, key) => {
                                                    return <Draggable index={key} draggableId={`${issue.id}`}>
                                                        {provided => (
                                                            <Flex ref={provided.innerRef} {...provided.dragHandleProps} {...provided.draggableProps} key={key} bg={"white"} align="center" borderRadius={5} p={1} justify={"center"}>
                                                                {issue.title}
                                                                {issue.position}
                                                            </Flex>
                                                        )
                                                        }
                                                    </Draggable>
                                                })
                                            }
                                            {provided.placeholder}
                                        </Stack>
                                    )
                                    }
                                </Droppable>
                            })}
                            <Tooltip label="Board hozzáadása">
                                <Flex
                                    height="90vh"
                                    width="200px"
                                    bg="green.200"
                                    p={2}
                                    align={"center"}
                                    justify={"center"}
                                    _hover={{ cursor: "pointer", bg: "green.300" }}
                                    onClick={() => onOpen()}
                                >
                                    <FaPlus size={40} />
                                </Flex>
                            </Tooltip>
                        </HStack>
                    </DragDropContext>

                </Flex >
            </>
        )
}
